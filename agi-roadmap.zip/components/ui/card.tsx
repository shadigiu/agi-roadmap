export const Card = ({ children, className }: any) => <div className={className}>{children}</div>;
export const CardContent = ({ children }: any) => <div>{children}</div>;